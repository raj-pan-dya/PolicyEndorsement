﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolicyEndorsement.Exceptions
{
    public class PolicyException : ApplicationException  //User Defined Exception class
    {
        public PolicyException():
            base()
        {

        }

        public PolicyException(string message):
            base(message)
        {

        }
    }
}
