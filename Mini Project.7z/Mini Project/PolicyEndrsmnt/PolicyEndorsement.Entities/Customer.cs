﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolicyEndorsement.Entities
{
    public class Customer
    {
        //Customer entities
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustAddress { get; set; }
        public string CustPhoneNo { get; set; }
        public char CustomerGender { get; set; }
        public DateTime CustDOB { get; set; }
        public string CustSmoker { get; set; }
        public string CustHobbies { get; set; }

        //Customer Constructor
        public Customer()
        {

        }
    }
}
